rootProject.name = "LiteSMT"

